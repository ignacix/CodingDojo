package com.cd.maestrodeobjetos.domain;

public class Ninja extends Human{

}
