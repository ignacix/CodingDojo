package com.cd.maestrodeobjetos.domain;

public class Wizard extends Human {
	
}
