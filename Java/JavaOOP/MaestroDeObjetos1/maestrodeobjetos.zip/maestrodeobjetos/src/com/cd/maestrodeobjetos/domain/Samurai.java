package com.cd.maestrodeobjetos.domain;

public class Samurai extends Human{

}
