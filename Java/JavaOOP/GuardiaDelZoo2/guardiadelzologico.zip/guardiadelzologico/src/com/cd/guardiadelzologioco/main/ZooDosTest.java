package com.cd.guardiadelzologioco.main;
import domain.Bat;
public class ZooDosTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat batman= new Bat();
		
		System.out.println(batman.getEnergyLevel());
		System.out.println(batman.attackTown());
		System.out.println(batman.attackTown());
		System.out.println(batman.attackTown());
		System.out.println(batman.getEnergyLevel());
		System.out.println(batman.eatHumans());
		System.out.println(batman.eatHumans());
		System.out.println(batman.getEnergyLevel());
		System.out.println(batman.fly());
		System.out.println(batman.getEnergyLevel());
	}

}
