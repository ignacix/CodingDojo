package com.cd.guardiadelzologioco.main;
import domain.Gorilla; 

public class ZooUnoTest{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		Gorilla mono1 = new Gorilla();
		System.out.println(mono1.throwSomething());
		System.out.println(mono1.throwSomething());
		System.out.println(mono1.throwSomething());
		System.out.println(mono1.displayEnergy());
		System.out.println(mono1.eatBananas());
		System.out.println(mono1.eatBananas());
		System.out.println(mono1.displayEnergy());
		System.out.println(mono1.climb());
		System.out.println(mono1.displayEnergy());
		

	}

}
