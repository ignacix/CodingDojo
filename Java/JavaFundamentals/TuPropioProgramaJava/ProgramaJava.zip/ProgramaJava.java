public class ProgramaJava {
    public static void main(String[] args){
        System.out.println("Mi nombre es Ignacio Jerez");
        System.out.println("Tengo 24 años de edad.");
        System.out.println("Mi ciudad es Maquinista Savio, Buenos Aires");
    }
}
