public class PitagorasTest {
    public static void main(String[] args) {
        Pitagoras clasePitagoras = new Pitagoras();
        double result = clasePitagoras.calcularHipotenusa(3,5);
        System.out.println("el resultado es "+ result);
    }
}
