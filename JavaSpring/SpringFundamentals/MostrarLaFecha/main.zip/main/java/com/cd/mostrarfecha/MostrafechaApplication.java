package com.cd.mostrarfecha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostrafechaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MostrafechaApplication.class, args);
	}

}
