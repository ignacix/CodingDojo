/**
 * 
 */
 
 function alerta(pagina){
	 alert("This is "  +pagina+" template");
 }