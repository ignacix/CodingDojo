package com.cd.licencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicenciaApplication.class, args);
	}

}
